package chatty;

import javax.swing.text.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

    public class Main {
        public static void main(String args[]) {

            frame1 f1 = new frame1();
            frame2 f2=new frame2();
            frame3 f3=new frame3();

            f1.frame_1();
            f2.frame_2();
            f3.frame_3();

            f1.setFrameB(f2);
            f2.setFrameA(f1);
            f3.setFrameB(f2);

            f3.setFrameA(f1);

            f1.setFrameC(f3);
            f2.setFrameC(f3);






        }
    }

